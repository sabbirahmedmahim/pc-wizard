<?php
session_start();
// Checkout e chap dile jate JS bujhte pare user login ache kina
$is_logged_in = (isset($_SESSION['user_logged_in']) &&$_SESSION['user_logged_in'] === true) ? 'true' : 'false';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart | PC WIZARD</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        html { scroll-behavior: smooth; }
        .cart-container { max-width: 1200px; margin: 3rem auto; padding: 0 2rem; display: grid; grid-template-columns: 2fr 1fr; gap: 3rem; }
        .cart-items { border: 1px solid var(--border-color); border-radius: 8px; padding: 2rem; background: #fff; }
        .cart-summary { border: 1px solid var(--border-color); border-radius: 8px; padding: 2rem; background: #f8f9fa; height: fit-content; }
        .cart-item-row { display: grid; grid-template-columns: 100px 1fr auto auto; align-items: center; gap: 1.5rem; padding: 1.5rem 0; border-bottom: 1px solid var(--border-color); }
        .cart-item-row:last-child { border-bottom: none; }
        .cart-item-img { width: 100%; height: 100px; object-fit: contain; border: 1px solid var(--border-color); border-radius: 4px; padding: 0.5rem; background: #fff;}
        .cart-item-info { display: flex; flex-direction: column; gap: 0.25rem; }
        .qty-btn { background: none; border: 1px solid var(--border-color); cursor: pointer; padding: 0.2rem 0.5rem; font-size: 1rem; border-radius: 4px; }
        .qty-btn:hover { background: var(--black); color: #fff; }
        .remove-btn { color: #ef4444; background: none; border: none; cursor: pointer; text-decoration: underline; font-size: 0.9rem; text-align: left; padding: 0;}
        
        .nav-logo { height: 95px !important; width: auto; max-height: none; margin: -10px 0; }
        .nav-item-dropdown { position: relative; display: inline-block; }
        .dropdown-content { display: none; position: absolute; background-color: #fff; min-width: 150px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); z-index: 100; border: 1px solid var(--border-color); border-radius: 4px; top: 100%; right: 0; }
        .dropdown-content a { color: var(--black); padding: 12px 16px; text-decoration: none; display: block; font-size: 0.9rem; border-bottom: 1px solid var(--border-color); }
        .dropdown-content a:hover { background-color: #f8f9fa; }
        .nav-item-dropdown:hover .dropdown-content { display: block; }
    </style>
</head>
<body>
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>

    <header class="header-wrapper">
        <nav class="navbar" style="border-bottom: 1px solid var(--border-color);">
            <a href="index.php" class="nav-brand"><img src="logo (2).png" alt="Logo" class="nav-logo"></a>
            <div class="nav-center">
                <a href="index.php" class="nav-link"><i data-lucide="home"></i> HOME</a>
                <a href="shop.php" class="nav-link"><i data-lucide="shopping-bag"></i> SHOP</a>
            </div>
            <div class="nav-right">
                <?php if(isset($_SESSION['user_logged_in']) &&$_SESSION['user_logged_in'] === true): ?>
                    <div class="nav-item-dropdown">
                        <a href="user_profile.php" class="auth-link" style="display:flex; align-items:center; gap:0.5rem; text-transform:uppercase;">
                            <i data-lucide="user" style="width:18px;"></i> HI, <?= htmlspecialchars($_SESSION['user_name']) ?>
                        </a>
                        <div class="dropdown-content">
                            <a href="user_profile.php">My Profile</a>
                            <a href="user_logout.php" style="color: #ef4444;">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="user_login.php" class="auth-link">LOGIN / REGISTER</a>
                <?php endif; ?>
                <a href="cart.php" class="icon-btn"><i data-lucide="shopping-cart"></i> <span class="cart-count badge" id="nav_cart_count">0</span></a>
            </div>
        </nav>
    </header>

    <div class="cart-container">
        <div class="cart-items">
            <h2 style="margin-bottom: 1.5rem; font-size: 1.5rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;">Shopping Cart</h2>
            <div id="cart_render_area"></div>
        </div>

        <div class="cart-summary">
            <h3 style="margin-bottom: 1.5rem; font-size: 1.25rem;">Order Summary</h3>
            <div style="display: flex; justify-content: space-between; margin-bottom: 1rem;">
                <span style="color: var(--text-muted);">Subtotal (<span id="summary_item_count">0</span> items)</span>
                <span id="cart_subtotal" style="font-weight: 600;">৳0.00</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 1rem;">
                <span style="color: var(--text-muted);">Delivery Charge</span>
                <span style="font-weight: 600;">৳150.00</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border-color); font-size: 1.25rem;">
                <span style="font-weight: 600;">Total</span>
                <span id="cart_grand_total" style="font-weight: 700; color: #10b981;">৳0.00</span>
            </div>
            
            <button onclick="processCheckout()" class="btn btn-solid" style="width: 100%; margin-top: 2rem; padding: 1rem; font-size: 1rem; display: flex; justify-content: center; align-items: center; gap: 0.5rem;">
                <i data-lucide="lock" style="width: 18px;"></i> PROCEED TO CHECKOUT
            </button>
        </div>
    </div>

    <script>
        function loadCartPage() {
            let cart = JSON.parse(localStorage.getItem('pc_wizard_cart')) || [];
            let cartArea = document.getElementById('cart_render_area');
            let subtotal = 0; let totalItems = 0;

            // Auto-fix corrupted cart data (NaN issue fix)
            if (cart.length > 0 && (isNaN(parseFloat(cart[0].price)) || cart[0].title === undefined)) {
                localStorage.removeItem('pc_wizard_cart');
                alert("Old corrupted cart data detected and cleared. Please add the product again.");
                window.location.reload();
                return;
            }

            if (cart.length === 0) {
                cartArea.innerHTML = '<div style="text-align: center; padding: 3rem; color: var(--text-muted);"><i data-lucide="shopping-cart" style="width: 48px; height: 48px; margin-bottom: 1rem; opacity: 0.5;"></i><h3>Your cart is empty</h3><a href="shop.php" style="color: var(--black); font-weight: bold; margin-top: 1rem; display: inline-block;">CONTINUE SHOPPING</a></div>';
                document.getElementById('cart_subtotal').innerText = '৳0.00';
                document.getElementById('cart_grand_total').innerText = '৳0.00';
                lucide.createIcons();
                return;
            }

            let html = '';
            cart.forEach((item, index) => {
                let price = parseFloat(item.price) || 0;
                let title = item.title || item.name || "PC Wizard Product";
                let image = item.image || item.image_url || "logo (2).png";
                let brand = item.brand || "PC WIZARD";
                let itemTotal = price * item.quantity;
                
                subtotal += itemTotal;
                totalItems += item.quantity;

                html += `
                    <div class="cart-item-row">
                        <img src="${image}" alt="${title}" class="cart-item-img">
                        <div class="cart-item-info">
                            <span style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase;">${brand}</span>
                            <strong style="font-size: 1.1rem;">${title}</strong>
                            <span style="color: var(--text-muted);">৳${price.toLocaleString('en-US', {minimumFractionDigits: 2})}</span>
                            <button class="remove-btn" onclick="removeItem(${index})"><i data-lucide="trash-2" style="width: 14px; display: inline-block; vertical-align: middle;"></i> Remove</button>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <button class="qty-btn" onclick="updateQty(${index}, -1)">-</button>
                            <span style="font-weight: 600; width: 20px; text-align: center;">${item.quantity}</span>
                            <button class="qty-btn" onclick="updateQty(${index}, 1)">+</button>
                        </div>
                        <div style="font-weight: 600; font-size: 1.1rem; text-align: right;">
                            ৳${itemTotal.toLocaleString('en-US', {minimumFractionDigits: 2})}
                        </div>
                    </div>
                `;
            });

            cartArea.innerHTML = html;
            let grandTotal = subtotal + 150;
            document.getElementById('cart_subtotal').innerText = '৳' + subtotal.toLocaleString('en-US', {minimumFractionDigits: 2});
            document.getElementById('cart_grand_total').innerText = '৳' + grandTotal.toLocaleString('en-US', {minimumFractionDigits: 2});
            document.getElementById('summary_item_count').innerText = totalItems;
            document.getElementById('nav_cart_count').innerText = totalItems;
            lucide.createIcons();
        }

        function updateQty(index, change) {
            let cart = JSON.parse(localStorage.getItem('pc_wizard_cart')) || [];
            if (cart[index]) {
                cart[index].quantity += change;
                if (cart[index].quantity < 1) cart.splice(index, 1);
                localStorage.setItem('pc_wizard_cart', JSON.stringify(cart));
                loadCartPage();
            }
        }

        function removeItem(index) {
            let cart = JSON.parse(localStorage.getItem('pc_wizard_cart')) || [];
            cart.splice(index, 1);
            localStorage.setItem('pc_wizard_cart', JSON.stringify(cart));
            loadCartPage();
        }

        function processCheckout() {
            let isLoggedIn = <?= $is_logged_in ?>;
            let cart = JSON.parse(localStorage.getItem('pc_wizard_cart')) || [];
            if(cart.length === 0) { alert("Your cart is empty!"); return; }
            if(!isLoggedIn) {
                alert("Please login to proceed to checkout!");
                window.location.href = 'user_login.php';
            } else {
                window.location.href = 'checkout.php';
            }
        }
        document.addEventListener('DOMContentLoaded', loadCartPage);
    </script>
    <script src="js/app.js"></script>
</body>
</html>