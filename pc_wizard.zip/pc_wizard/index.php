<?php
session_start();
try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->query("SELECT p.*, b.name AS brand, c.name AS category FROM products p LEFT JOIN brands b ON p.brand_id = b.id LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC LIMIT 4");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $nav_stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC LIMIT 6");
    $nav_categories = $nav_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $products = []; $nav_categories = [];
}
function getCategoryIcon($catName) {
    $name = strtolower($catName);
    if (strpos($name, 'processor') !== false || strpos($name, 'cpu') !== false) return 'cpu';
    if (strpos($name, 'mouse') !== false) return 'mouse';
    if (strpos($name, 'keyboard') !== false) return 'keyboard';
    if (strpos($name, 'hdd') !== false || strpos($name, 'ssd') !== false) return 'hard-drive';
    if (strpos($name, 'monitor') !== false) return 'monitor';
    return 'box';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PC WIZARD | Power Your Performance</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        html { scroll-behavior: smooth; }
        .nav-logo { height: 95px !important; width: auto; max-height: none; margin: -10px 0; }
        .nav-item-dropdown { position: relative; display: inline-block; }
        .dropdown-content { display: none; position: absolute; background-color: #fff; min-width: 150px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); z-index: 100; border: 1px solid var(--border-color); border-radius: 4px; top: 100%; right: 0; }
        .dropdown-content a { color: var(--black); padding: 12px 16px; text-decoration: none; display: block; font-size: 0.9rem; border-bottom: 1px solid var(--border-color); }
        .dropdown-content a:hover { background-color: #f8f9fa; }
        .nav-item-dropdown:hover .dropdown-content { display: block; }
        .search-box { display: flex; align-items: center; border: 1px solid var(--border-color); border-radius: 20px; padding: 2px 10px; background: #fff; }
        .search-box input { border: none; outline: none; padding: 5px 10px; width: 180px; background: transparent; }
        .banner-showcase { display: grid; grid-template-columns: 2.5fr 1fr; gap: 1.5rem; padding: 2rem 0; }
        .banner-item { border-radius: 8px; overflow: hidden; display: block; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .banner-item img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 0.3s ease;}
        .banner-item:hover img { transform: scale(1.02); }
        .side-banners { display: flex; flex-direction: column; gap: 1.5rem; }
    </style>
</head>
<body>
    <div class="cursor-dot"></div><div class="cursor-outline"></div>
    <header class="header-wrapper">
        <nav class="navbar" style="border-bottom: 1px solid var(--border-color);">
            <a href="index.php" class="nav-brand"><img src="logo (2).png" alt="PC WIZARD" class="nav-logo"></a>
            <div class="nav-center">
                <a href="index.php" class="nav-link"><i data-lucide="home"></i> HOME</a>
                <div class="nav-item-dropdown">
                    <a href="shop.php" class="nav-link"><i data-lucide="shopping-bag"></i> SHOP <i data-lucide="chevron-down"></i></a>
                    <div class="dropdown-content">
                        <?php foreach($nav_categories as $cat): ?>
                            <a href="shop.php?category=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <a href="#contact-footer" class="nav-link"><i data-lucide="phone-call"></i> CONTACT US</a>
            </div>
            <div class="nav-right">
                <!-- Dynamic User Profile in Header -->
                <?php if(isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true): ?>
                    <div class="nav-item-dropdown">
                        <a href="user_profile.php" class="auth-link" style="display:flex; align-items:center; gap:0.5rem; text-transform:uppercase;">
                            <i data-lucide="user" style="width:18px;"></i> HI, <?= htmlspecialchars($_SESSION['user_name']) ?>
                        </a>
                        <div class="dropdown-content">
                            <a href="user_profile.php" style="color: var(--black);">My Profile</a>
                            <a href="user_logout.php" style="color: #ef4444;">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="user_login.php" class="auth-link">LOGIN / REGISTER</a>
                <?php endif; ?>

                <form action="shop.php" method="GET" class="search-box">
                    <input type="text" name="search" placeholder="Search products...">
                    <button type="submit" style="background:none; border:none; cursor:pointer;"><i data-lucide="search" style="width: 18px;"></i></button>
                </form>
                <a href="cart.php" class="icon-btn"><i data-lucide="shopping-cart"></i> <span class="cart-count badge" id="nav_cart_count">0</span></a>
            </div>
        </nav>
    </header>

    <section class="page-container" style="padding-bottom: 0;">
        <div class="banner-showcase">
            <a href="shop.php" class="banner-item"><img src="banner1.png" alt="Main Banner" style="min-height: 400px;"></a>
            <div class="side-banners">
                <a href="shop.php" class="banner-item"><img src="banner2.png" alt="Side Banner 1"></a>
                <a href="#contact-footer" class="banner-item"><img src="banner3.png" alt="Side Banner 2"></a>
            </div>
        </div>
    </section>

    <section class="category-section">
        <div class="category-grid">
            <?php foreach(array_slice($nav_categories, 0, 5) as $cat): ?>
            <a href="shop.php?category=<?= $cat['id'] ?>" class="category-card" style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1rem; padding: 2.5rem 1rem;">
                <i data-lucide="<?= getCategoryIcon($cat['name']) ?>" style="width: 48px; height: 48px; color: var(--black);"></i>
                <span style="font-weight: 600; font-size: 1.1rem; text-transform: uppercase;"><?= htmlspecialchars($cat['name']) ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="page-container" style="padding-top: 0;">
        <div style="text-align: center; margin-bottom: 3rem;"><h2>Latest Arrivals</h2></div>
        
        <div class="product-grid" id="featured-grid">
            <?php foreach($products as $p): ?>
            <div class="product-card">
                <a href="product.php?id=<?= $p['id'] ?>" class="product-image"><img src="<?= htmlspecialchars($p['image_url']) ?>" alt="Product"></a>
                <div class="product-info">
                    <div>
                        <div class="product-brand"><?= htmlspecialchars($p['brand'] ?? 'General') ?></div>
                        <div class="product-title"><?= htmlspecialchars($p['title']) ?></div>
                    </div>
                    <div class="product-price">৳<?= number_format($p['price'], 2) ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- View All Button Added Here -->
        <div style="text-align: center; margin-top: 3rem;">
            <a href="shop.php" class="btn btn-outline" style="width: auto; padding: 1rem 3rem; font-size: 1.1rem;">VIEW ALL PRODUCTS</a>
        </div>
    </section>

    <footer class="footer" id="contact-footer">
        <div class="footer-grid">
            <div class="footer-brand">
                <img src="logo (2).png" alt="PC WIZARD Logo" style="height: 60px;">
                <p>PC WIZARD ensures top-tier performance and reliable customer service.</p>
                <div style="margin-top: 1rem; color: var(--text-muted);">
                    <div><i data-lucide="phone" style="width: 16px;"></i> +880 9603-300300</div>
                    <div><i data-lucide="map-pin" style="width: 16px;"></i> Mirpur 10, Dhaka</div>
                </div>
            </div>
            <div class="footer-col">
                <h4>LINKS</h4>
                <ul><li><a href="admin/login.php" style="color: var(--black); font-weight: 600;">Admin Panel</a></li></ul>
            </div>
        </div>
    </footer>
    <script src="js/app.js"></script>
</body>
</html>