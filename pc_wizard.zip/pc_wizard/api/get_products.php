<?php
header('Content-Type: application/json');
require '../admin/db.php'; // Database file connect করা হলো

// ডাটাবেস থেকে সর্বশেষ ৪টি প্রোডাক্ট নিবো হোমপেজের জন্য
$stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 4");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($products);
?>