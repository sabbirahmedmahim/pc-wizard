<?php
// Turn on error reporting to stop white screens
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = 'localhost';
$dbname = 'pc_wizard_db';
$user = 'root';
$pass = ''; // Leave blank for standard XAMPP

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    // Force PDO to throw exceptions if the database connection fails
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // If database is missing, it will print this error instead of a white screen
    die("<h3 style='color:red; font-family:sans-serif;'>Database Connection Failed: " . $e->getMessage() . "</h3><p>Did you create pc_wizard_db in phpMyAdmin?</p>");
}