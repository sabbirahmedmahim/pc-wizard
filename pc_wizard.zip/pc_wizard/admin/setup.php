<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    // 1. Direct Database Connection
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 2. Delete the broken dummy user
    $pdo->query("DELETE FROM admins WHERE username = 'office_admin'");

    // 3. Generate a real, secure hash for the password 'admin123'
    $real_hash = password_hash('admin123', PASSWORD_DEFAULT);

    // 4. Insert the working user into the database
    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES ('office_admin', ?)");
    $stmt->execute([$real_hash]);

    echo "<h2 style='color: green; font-family: sans-serif; text-align: center; margin-top: 50px;'>
            Admin account fixed successfully! <br><br>
            Username: office_admin <br>
            Password: admin123
          </h2>";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>