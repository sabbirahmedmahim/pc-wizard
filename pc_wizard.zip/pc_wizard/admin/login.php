<?php
session_start();
$error = '';

// Catch database errors to prevent the blank white screen
try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Login Logic
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['admin_logged_in'] = true;
            header("Location: dashboard.php");
            exit;
        } else {
            $error = 'Invalid username or password!';
        }
    }
} catch (PDOException $e) {
    // If the database fails, we store the error string here to show in the HTML
    $error = "DATABASE ERROR: " . $e->getMessage() . " -> Please check phpMyAdmin.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login | PC WIZARD</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body style="display: flex; align-items: center; justify-content: center; height: 100vh; background: var(--surface-color);">
    
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>

    <div style="background: var(--white); padding: 4rem; border: 1px solid var(--border-color); width: 100%; max-width: 400px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
        <h2 style="text-align: center; margin-bottom: 2rem; font-size: 1.5rem;">OFFICE ADMIN</h2>
        
        <?php if ($error): ?>
            <p style="color: red; margin-bottom: 1.5rem; font-size: 0.875rem; text-align: center; font-weight: 600; padding: 0.5rem; border: 1px solid red; background: #fff5f5;">
                <?= htmlspecialchars($error) ?>
            </p>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-size: 0.75rem; text-transform: uppercase;">Username</label>
                <input type="text" name="username" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color);" required>
            </div>
            <div style="margin-bottom: 2rem;">
                <label style="display: block; margin-bottom: 0.5rem; font-size: 0.75rem; text-transform: uppercase;">Password</label>
                <input type="password" name="password" style="width: 100%; padding: 0.75rem; border: 1px solid var(--border-color);" required>
            </div>
            <button type="submit" class="btn btn-solid" style="width: 100%;">LOGIN</button>
        </form>
    </div>

    <script>
        lucide.createIcons();
        const cursorDot = document.querySelector('.cursor-dot');
        const cursorOutline = document.querySelector('.cursor-outline');
        if(cursorDot && cursorOutline) {
            window.addEventListener('mousemove', (e) => {
                cursorDot.style.left = e.clientX + 'px';
                cursorDot.style.top = e.clientY + 'px';
                cursorOutline.animate({ left: e.clientX + 'px', top: e.clientY + 'px' }, { duration: 150, fill: "forwards" });
            });
            document.querySelectorAll('a, button, input').forEach(el => {
                el.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
                el.addEventListener('mouseleave', () => document.body.classList.remove('cursor-hover'));
            });
        }
    </script>
</body>
</html>