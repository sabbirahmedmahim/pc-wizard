<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $brand_name = trim($_POST['brand']);
    $title = trim($_POST['title']);
    $price = $_POST['price'];
    $category_name = trim($_POST['category']);
    $image_url = trim($_POST['image_url']);
    $added_stock = (int)$_POST['stock'];

    // 1. Brand
    $stmt = $pdo->prepare("SELECT id FROM brands WHERE name = ?");
    $stmt->execute([$brand_name]);
    $brand = $stmt->fetch();
    if ($brand) { $brand_id = $brand['id']; } 
    else {
        $stmt = $pdo->prepare("INSERT INTO brands (name) VALUES (?)");
        $stmt->execute([$brand_name]);
        $brand_id = $pdo->lastInsertId();
    }

    // 2. Category
    $stmt = $pdo->prepare("SELECT id FROM categories WHERE name = ?");
    $stmt->execute([$category_name]);
    $category = $stmt->fetch();
    if ($category) { $category_id = $category['id']; } 
    else {
        $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->execute([$category_name]);
        $category_id = $pdo->lastInsertId();
    }

    // 3. Smart Upsert Logic with your existing 'stock_quantity' column
    $checkStmt = $pdo->prepare("SELECT id, stock_quantity FROM products WHERE title = ? AND brand_id = ?");
    $checkStmt->execute([$title, $brand_id]);
    $existingProduct = $checkStmt->fetch();

    if ($existingProduct) {
        $newStock = $existingProduct['stock_quantity'] + $added_stock; 
        $updateStmt = $pdo->prepare("UPDATE products SET stock_quantity = ?, price = ?, image_url = ? WHERE id = ?");
        $updateStmt->execute([$newStock, $price, $image_url, $existingProduct['id']]);
    } else {
        $insertStmt = $pdo->prepare("INSERT INTO products (title, category_id, brand_id, price, stock_quantity, image_url) VALUES (?, ?, ?, ?, ?, ?)");
        $insertStmt->execute([$title, $category_id, $brand_id, $price, $added_stock, $image_url]);
    }
    
    header("Location: dashboard.php");
    exit;
}

$stmt = $pdo->query("
    SELECT p.id, p.title, p.price, p.image_url, p.stock_quantity, b.name AS brand_name, c.name AS category_name 
    FROM products p 
    LEFT JOIN brands b ON p.brand_id = b.id 
    LEFT JOIN categories c ON p.category_id = c.id 
    ORDER BY p.id DESC
");
$inventory = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | PC WIZARD OFFICE</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        /* Form grid width updated to 400px and styling fixed */
        .dashboard-layout { display: grid; grid-template-columns: 400px 1fr; gap: 3rem; padding: 3rem; max-width: 1400px; margin: 0 auto; }
        .add-form-container { background: #f8f9fa; padding: 2rem; border-radius: 8px; border: 1px solid var(--border-color); height: fit-content;}
        .form-input { width: 100%; box-sizing: border-box; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 4px; outline: none; margin-top: 0.5rem; font-family: inherit;}
        .form-input:focus { border-color: var(--black); }
        .inventory-list { width: 100%; border-collapse: collapse; }
        .inventory-list th, .inventory-list td { padding: 1.5rem 1rem; text-align: left; border-bottom: 1px solid var(--border-color); }
        .inventory-list img { width: 50px; height: 50px; object-fit: contain; }
        .logout-btn { width: auto !important; padding: 0.5rem 1.2rem !important; display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>

    <header style="padding: 1.5rem 3rem; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; background: #fff;">
        <a href="../index.php"><img src="../logo (2).png" alt="PC WIZARD Logo" style="height: 45px; width: auto;"></a>
        <a href="logout.php" class="btn btn-outline logout-btn"><i data-lucide="log-out" style="width: 18px; height: 18px;"></i> LOGOUT</a>
    </header>

    <div class="dashboard-layout">
        <div class="add-form-container">
            <h3 style="margin-bottom: 2rem; font-size: 1rem;">ADD / UPDATE PRODUCT</h3>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: -1.5rem; margin-bottom: 1.5rem;">If product exists, entered stock will be added to current stock.</p>
            <form method="POST">
                <div class="form-group" style="margin-bottom: 1.5rem;">
                    <label class="form-label" style="font-size: 0.75rem; color: var(--text-muted);">BRAND</label>
                    <input type="text" name="brand" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom: 1.5rem;">
                    <label class="form-label" style="font-size: 0.75rem; color: var(--text-muted);">PRODUCT TITLE</label>
                    <input type="text" name="title" class="form-input" required>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
                    <div class="form-group">
                        <label class="form-label" style="font-size: 0.75rem; color: var(--text-muted);">PRICE (৳)</label>
                        <input type="number" name="price" step="0.01" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label" style="font-size: 0.75rem; color: var(--text-muted);">STOCK (Pieces)</label>
                        <input type="number" name="stock" class="form-input" required>
                    </div>
                </div>
                <div class="form-group" style="margin-bottom: 1.5rem;">
                    <label class="form-label" style="font-size: 0.75rem; color: var(--text-muted);">CATEGORY</label>
                    <input type="text" name="category" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom: 2rem;">
                    <label class="form-label" style="font-size: 0.75rem; color: var(--text-muted);">IMAGE URL</label>
                    <input type="url" name="image_url" class="form-input" required>
                </div>
                <button type="submit" name="add_product" class="btn btn-solid" style="width: 100%;">SAVE PRODUCT</button>
            </form>
        </div>

        <div>
            <h3 style="margin-bottom: 2rem; font-size: 1rem;">CURRENT INVENTORY</h3>
            <table class="inventory-list">
                <thead>
                    <tr>
                        <th style="font-size: 0.75rem; color: var(--text-muted);">IMAGE</th>
                        <th style="font-size: 0.75rem; color: var(--text-muted);">PRODUCT</th>
                        <th style="font-size: 0.75rem; color: var(--text-muted);">PRICE</th>
                        <th style="font-size: 0.75rem; color: var(--text-muted);">CATEGORY</th>
                        <th style="font-size: 0.75rem; color: var(--text-muted);">STOCK</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($inventory as $item): ?>
                    <tr>
                        <td><img src="<?= htmlspecialchars($item['image_url']) ?>" alt="Product"></td>
                        <td>
                            <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase;"><?= htmlspecialchars($item['brand_name']) ?></div>
                            <div style="font-weight: 600;"><?= htmlspecialchars($item['title']) ?></div>
                        </td>
                        <td>৳<?= number_format($item['price'], 2) ?></td>
                        <td><?= htmlspecialchars($item['category_name']) ?></td>
                        <td>
                            <span style="background: <?= ($item['stock_quantity'] > 0) ? '#d1fae5; color: #059669;' : '#fee2e2; color: #dc2626;' ?> padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.85rem; font-weight: 600;">
                                <?= (int)$item['stock_quantity'] ?> Pcs
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="../js/app.js"></script>
</body>
</html>