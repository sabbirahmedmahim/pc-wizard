<?php
try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    
    $hash = password_hash("admin123", PASSWORD_DEFAULT);
    
    
    $stmt = $pdo->prepare("UPDATE admins SET password_hash = ? WHERE username = 'office_admin'");
    $stmt->execute([$hash]);
    
    echo "<h1>Password Reset Successful!</h1>";
    echo "<p>Ekhon apni <b>admin123</b> diye login korte parben.</p>";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>