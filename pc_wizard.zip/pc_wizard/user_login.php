<?php
session_start();
$error = ''; $success = '';

if (isset($_SESSION['user_logged_in'])) { header("Location: index.php"); exit; }

try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // REGISTRATION
        if (isset($_POST['register_user'])) {
            $first_name = trim($_POST['first_name']);
            $last_name = trim($_POST['last_name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone']);
            $address = trim($_POST['address']);
            $city = trim($_POST['city']);
            $password = $_POST['password'];
            
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = "An account with this email already exists!";
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, email, phone, address, city, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$first_name, $last_name, $email, $phone, $address, $city, $password_hash]);
                $success = "Account created successfully! Please log in on the left.";
            }
        }
        // LOGIN
        elseif (isset($_POST['login_user'])) {
            $email = trim($_POST['email']);
            $password = $_POST['password'];

            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_logged_in'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['first_name'];
                header("Location: index.php");
                exit;
            } else {
                $error = "Invalid email or password!";
            }
        }
    }
} catch (PDOException $e) { $error = "Database Error"; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Register | PC WIZARD</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        .auth-container { max-width: 1100px; margin: 4rem auto; display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; padding: 0 2rem; align-items: start;}
        .auth-box { border: 1px solid var(--border-color); padding: 3rem; border-radius: 8px; background: #fff; height: 100%; box-sizing: border-box;}
        
        /* Updated Input Styles to prevent overflow */
        .form-input { width: 100%; box-sizing: border-box; padding: 0.8rem; border: 1px solid var(--border-color); border-radius: 4px; outline: none; margin-top: 0.5rem; font-family: inherit;}
        .form-input:focus { border-color: var(--black); }
        .form-group { margin-bottom: 1.5rem; }
        
        .alert { padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem; text-align: center; font-weight: 600; box-sizing: border-box;}
        .alert-error { background: #fee2e2; color: #dc2626; border: 1px solid #f87171; }
        .alert-success { background: #d1fae5; color: #059669; border: 1px solid #34d399; }
    </style>
</head>
<body>
    <div class="cursor-dot"></div><div class="cursor-outline"></div>
    <header style="padding: 1.5rem; border-bottom: 1px solid var(--border-color); text-align: center; background: #fff;">
        <a href="index.php"><img src="logo (2).png" alt="Logo" style="height: 70px;"></a>
    </header>

    <div class="auth-container">
        <div style="grid-column: 1 / -1;">
            <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
        </div>

        <!-- LOGIN BOX -->
        <div class="auth-box">
            <h2 style="font-size: 1.5rem; margin-bottom: 2.5rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;">EXISTING CUSTOMER</h2>
            <form action="user_login.php" method="POST">
                <div class="form-group">
                    <label class="form-label">Email Address *</label>
                    <input type="email" name="email" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom: 2.5rem;">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-input" required>
                </div>
                <button type="submit" name="login_user" class="btn btn-solid" style="width: 100%; padding: 1rem; font-size: 1.1rem;">LOG IN</button>
            </form>
        </div>

        <!-- REGISTER BOX -->
        <div class="auth-box">
            <h2 style="font-size: 1.5rem; margin-bottom: 2.5rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;">NEW CUSTOMER</h2>
            <form action="user_login.php" method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                    <div>
                        <label class="form-label">First Name *</label>
                        <input type="text" name="first_name" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label">Last Name *</label>
                        <input type="text" name="last_name" class="form-input" required>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                    <div>
                        <label class="form-label">Email Address *</label>
                        <input type="email" name="email" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label">Phone Number *</label>
                        <input type="text" name="phone" class="form-input" required>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                    <div>
                        <label class="form-label">Address *</label>
                        <input type="text" name="address" class="form-input" placeholder="House/Road" required>
                    </div>
                    <div>
                        <label class="form-label">City *</label>
                        <input type="text" name="city" class="form-input" required>
                    </div>
                </div>
                
                <div class="form-group" style="margin-bottom: 2.5rem;">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-input" required>
                </div>
                <button type="submit" name="register_user" class="btn btn-outline" style="width: 100%; padding: 1rem; font-size: 1.1rem;">CREATE ACCOUNT</button>
            </form>
        </div>
    </div>
    <script src="js/app.js"></script>
</body>
</html>