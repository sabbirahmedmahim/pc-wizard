<?php
session_start();
try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fetch categories
    $cat_stmt = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC");
    $categories = $cat_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Dynamic Query
    $query = "SELECT p.*, b.name AS brand, c.name AS category FROM products p LEFT JOIN brands b ON p.brand_id = b.id LEFT JOIN categories c ON p.category_id = c.id WHERE 1=1";
    $params = [];

    // Search
    $search_query = "";
    if (!empty($_GET['search'])) {
        $query .= " AND (p.title LIKE ? OR b.name LIKE ?)";
        $params[] = "%" . $_GET['search'] . "%";
        $params[] = "%" . $_GET['search'] . "%";
        $search_query = $_GET['search'];
    }

    // Category
    $current_category = "";
    if (!empty($_GET['category'])) {
        $query .= " AND p.category_id = ?";
        $params[] = $_GET['category'];
        $current_category = $_GET['category'];
    }

    // Sorting Logic
    $sort = $_GET['sort'] ?? 'latest';
    if ($sort === 'price_low') {
        $query .= " ORDER BY p.price ASC";
    } elseif ($sort === 'price_high') {
        $query .= " ORDER BY p.price DESC";
    } else {
        $query .= " ORDER BY p.id DESC";
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catalog | PC WIZARD</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        html { scroll-behavior: smooth; }
        .nav-logo { height: 95px !important; width: auto; max-height: none; margin: -10px 0; }
        .nav-item-dropdown { position: relative; display: inline-block; }
        .dropdown-content { display: none; position: absolute; background-color: #fff; min-width: 150px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); z-index: 100; border: 1px solid var(--border-color); border-radius: 4px; top: 100%; right: 0; }
        .dropdown-content a { color: var(--black); padding: 12px 16px; text-decoration: none; display: block; font-size: 0.9rem; border-bottom: 1px solid var(--border-color); }
        .dropdown-content a:hover { background-color: #f8f9fa; }
        .nav-item-dropdown:hover .dropdown-content { display: block; }
        .search-box { display: flex; align-items: center; border: 1px solid var(--border-color); border-radius: 20px; padding: 2px 10px; background: #fff; }
        .search-box input { border: none; outline: none; padding: 5px 10px; font-size: 0.9rem; width: 180px; background: transparent; }
        .shop-layout { display: grid; grid-template-columns: 250px 1fr; gap: 3rem; margin-top: 2rem; }
        .sort-select { padding: 0.5rem 1rem; border: 1px solid var(--border-color); border-radius: 4px; outline: none; background: #fff; cursor: pointer; }
    </style>
</head>
<body>
    <!-- Mouse Animation Divs -->
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>

    <header class="header-wrapper">
        <nav class="navbar" style="border-bottom: 1px solid var(--border-color);">
            <a href="index.php" class="nav-brand"><img src="logo (2).png" alt="PC WIZARD Logo" class="nav-logo"></a>
            
            <div class="nav-center">
                <a href="index.php" class="nav-link"><i data-lucide="home"></i> HOME</a>
                <div class="nav-item-dropdown">
                    <a href="shop.php" class="nav-link"><i data-lucide="shopping-bag"></i> SHOP <i data-lucide="chevron-down"></i></a>
                    <div class="dropdown-content">
                        <?php foreach(array_slice($categories, 0, 6) as $cat): ?>
                            <a href="shop.php?category=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <a href="#contact-footer" class="nav-link"><i data-lucide="phone-call"></i> CONTACT US</a>
            </div>

            <div class="nav-right">
                <?php if(isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true): ?>
                    <div class="nav-item-dropdown">
                        <a href="user_profile.php" class="auth-link" style="display:flex; align-items:center; gap:0.5rem; text-transform:uppercase;">
                            <i data-lucide="user" style="width:18px;"></i> HI, <?= htmlspecialchars($_SESSION['user_name']) ?>
                        </a>
                        <div class="dropdown-content">
                            <a href="user_profile.php" style="color: var(--black);">My Profile</a>
                            <a href="user_logout.php" style="color: #ef4444;">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="user_login.php" class="auth-link">LOGIN / REGISTER</a>
                <?php endif; ?>

                <form action="shop.php" method="GET" class="search-box">
                    <input type="text" name="search" value="<?= htmlspecialchars($search_query) ?>" placeholder="Search products...">
                    <button type="submit" style="background:none; border:none; cursor:pointer;"><i data-lucide="search" style="width: 18px;"></i></button>
                </form>
                <a href="cart.php" class="icon-btn"><i data-lucide="shopping-cart"></i> <span class="cart-count badge">0</span></a>
            </div>
        </nav>
    </header>

    <div class="page-container">
        <div class="shop-header" style="margin-bottom: 2rem;">
            <h1 style="font-size: 2.5rem; margin-bottom: 0.5rem;">CATALOG</h1>
            <?php if($search_query): ?>
                <p style="color: var(--text-muted);">Search results for: "<?= htmlspecialchars($search_query) ?>"</p>
            <?php endif; ?>
        </div>

        <div class="shop-layout">
            <aside class="sidebar">
                <h3 style="margin-bottom: 1.5rem; font-size: 1.25rem;">CATEGORIES</h3>
                <ul style="list-style: none; padding: 0;">
                    <li style="margin-bottom: 0.75rem;">
                        <a href="shop.php" style="color: <?= empty($current_category) ? 'var(--black); font-weight: bold;' : 'var(--text-muted);' ?> text-decoration: none;">All Products</a>
                    </li>
                    <?php foreach($categories as $cat): ?>
                    <li style="margin-bottom: 0.75rem;">
                        <a href="shop.php?category=<?= $cat['id'] ?>" style="color: <?= ($current_category == $cat['id']) ? 'var(--black); font-weight: bold;' : 'var(--text-muted);' ?> text-decoration: none;">
                            <?= htmlspecialchars($cat['name']) ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </aside>

            <main>
                <!-- Sorting Bar -->
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; padding-bottom: 1rem; border-bottom: 1px solid var(--border-color);">
                    <span style="color: var(--text-muted);">Showing <?= count($products) ?> products</span>
                    
                    <select class="sort-select" onchange="window.location.href=this.value;">
                        <?php 
                            $base_url = "shop.php?";
                            if($current_category) $base_url .= "category=".$current_category."&";
                            if($search_query) $base_url .= "search=".urlencode($search_query)."&";
                        ?>
                        <option value="<?= $base_url ?>sort=latest" <?= $sort == 'latest' ? 'selected' : '' ?>>SORT BY: LATEST</option>
                        <option value="<?= $base_url ?>sort=price_low" <?= $sort == 'price_low' ? 'selected' : '' ?>>PRICE: LOW TO HIGH</option>
                        <option value="<?= $base_url ?>sort=price_high" <?= $sort == 'price_high' ? 'selected' : '' ?>>PRICE: HIGH TO LOW</option>
                    </select>
                </div>

                <div class="product-grid" id="shop-grid">
                    <?php if(empty($products)): ?>
                        <div style="grid-column: 1/-1; text-align: center; padding: 3rem; background: #f8f9fa; border-radius: 8px;">
                            <h3 style="color: var(--text-muted);">No products found matching your criteria.</h3>
                        </div>
                    <?php else: ?>
                        <?php foreach($products as $p): ?>
                        <div class="product-card">
                            <a href="product.php?id=<?= $p['id'] ?>" class="product-image">
                                <img src="<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['title']) ?>">
                            </a>
                            <div class="product-info">
                                <div>
                                    <div class="product-brand"><?= htmlspecialchars($p['brand'] ?? 'General') ?></div>
                                    <div class="product-title"><?= htmlspecialchars($p['title']) ?></div>
                                </div>
                                <div class="product-price">৳<?= number_format($p['price'], 2) ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>

    <footer class="footer" id="contact-footer" style="margin-top: 4rem;">
        <div class="footer-grid">
            <div class="footer-brand">
                <img src="logo (2).png" alt="PC WIZARD Logo" style="height: 60px; margin-bottom: 1.5rem;">
                <p>PC WIZARD is made by ENTHUSIASTS, ensuring top-tier performance.</p>
            </div>
            <div class="footer-col">
                <h4>IMPORTANT LINKS</h4>
                <ul><li><a href="admin/login.php" style="color: var(--black); font-weight: 600;">Admin Panel</a></li></ul>
            </div>
        </div>
    </footer>

    <!-- JS for Mouse Animation & Cart -->
    <script src="js/app.js"></script>
</body>
</html>