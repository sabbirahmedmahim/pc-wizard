// --- Custom Mouse Cursor Logic ---
const cursorDot = document.querySelector('.cursor-dot');
const cursorOutline = document.querySelector('.cursor-outline');

if (cursorDot && cursorOutline) {
    window.addEventListener('mousemove', (e) => {
        const posX = e.clientX;
        const posY = e.clientY;
        
        cursorDot.style.left = `${posX}px`;
        cursorDot.style.top = `${posY}px`;
        
        // Add a slight delay to the outline for smooth effect
        cursorOutline.animate({
            left: `${posX}px`,
            top: `${posY}px`
        }, { duration: 500, fill: "forwards" });
    });
}

// --- Add to Cart Logic ---
function addToCart(id, title, price, image, brand = "PC WIZARD") {
    // Get existing cart from Local Storage
    let cart = JSON.parse(localStorage.getItem('pc_wizard_cart')) || [];
    
    // Check if product already exists in cart
    let existingProduct = cart.find(item => item.id === id);
    
    if (existingProduct) {
        existingProduct.quantity += 1;
    } else {
        // Push full perfect data to cart array
        cart.push({
            id: id,
            title: title,
            price: parseFloat(price),
            image: image,
            brand: brand,
            quantity: 1
        });
    }
    
    // Save back to Local Storage
    localStorage.setItem('pc_wizard_cart', JSON.stringify(cart));
    
    // Update Navbar Badge immediately
    updateNavCartCount();

    // Show Beautiful Toast Notification
    showToast(`Added to cart: ${title}`);
}

// --- Update Navbar Badge ---
function updateNavCartCount() {
    let cart = JSON.parse(localStorage.getItem('pc_wizard_cart')) || [];
    let totalItems = 0;
    
    cart.forEach(item => {
        totalItems += item.quantity;
    });

    // Update all elements with class 'cart-count' or id 'nav_cart_count'
    const badges = document.querySelectorAll('.cart-count, #nav_cart_count');
    badges.forEach(badge => {
        badge.innerText = totalItems;
    });
}

// --- Toast Notification Logic ---
function showToast(message) {
    const toastContainer = document.getElementById('toast_container');
    if (!toastContainer) return;

    const toast = document.createElement('div');
    toast.style.background = '#111827';
    toast.style.color = '#fff';
    toast.style.padding = '12px 20px';
    toast.style.borderRadius = '4px';
    toast.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
    toast.style.fontSize = '0.9rem';
    toast.style.fontWeight = '600';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '10px';
    toast.style.transform = 'translateY(100%)';
    toast.style.opacity = '0';
    toast.style.transition = 'all 0.3s ease';

    toast.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> ${message}`;

    toastContainer.appendChild(toast);

    // Animate In
    setTimeout(() => {
        toast.style.transform = 'translateY(0)';
        toast.style.opacity = '1';
    }, 100);

    // Animate Out & Remove
    setTimeout(() => {
        toast.style.transform = 'translateY(100%)';
        toast.style.opacity = '0';
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Run on page load to initialize icons and cart count
document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    updateNavCartCount();
});