const products = [
    {
        id: "p1",
        name: "Void Studio Headphones",
        brand: "Aura",
        category: "Audio",
        price: 399.00,
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop",
        hoverImage: "https://images.unsplash.com/photo-1583394837494-b258547b74bd?q=80&w=800&auto=format&fit=crop",
        isNew: true
    },
    {
        id: "p2",
        name: "Monolith Mechanical Keyboard",
        brand: "Krono",
        category: "Accessories",
        price: 249.00,
        image: "https://images.unsplash.com/photo-1595225476474-87563907a212?q=80&w=800&auto=format&fit=crop",
        hoverImage: "https://images.unsplash.com/photo-1601445638532-3c6f6c3aa1d6?q=80&w=800&auto=format&fit=crop",
        isNew: false
    },
    {
        id: "p3",
        name: "Onyx Smart Watch",
        brand: "Lumina",
        category: "Wearables",
        price: 599.00,
        image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?q=80&w=800&auto=format&fit=crop",
        hoverImage: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?q=80&w=800&auto=format&fit=crop",
        isNew: true
    },
    {
        id: "p4",
        name: "Eclipse Leather Tote",
        brand: "Maison",
        category: "Bags",
        price: 850.00,
        image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?q=80&w=800&auto=format&fit=crop",
        hoverImage: "https://images.unsplash.com/photo-1584916201218-f4242ceb4809?q=80&w=800&auto=format&fit=crop",
        isNew: false
    },
    {
        id: "p5",
        name: "Minimalist Object Camera",
        brand: "Optic",
        category: "Tech",
        price: 1200.00,
        image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=800&auto=format&fit=crop",
        hoverImage: "https://images.unsplash.com/photo-1502982720700-baf97fe1e56a?q=80&w=800&auto=format&fit=crop",
        isNew: true
    },
    {
        id: "p6",
        name: "Noir Ceramic Mug",
        brand: "Object",
        category: "Home",
        price: 45.00,
        image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?q=80&w=800&auto=format&fit=crop",
        hoverImage: "https://images.unsplash.com/photo-1481833761820-0509d3217039?q=80&w=800&auto=format&fit=crop",
        isNew: false
    }
];