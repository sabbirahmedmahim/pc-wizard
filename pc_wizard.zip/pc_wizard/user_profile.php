<?php
session_start();

// Security Check
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: user_login.php");
    exit;
}

$msg = '';

try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $user_id = $_SESSION['user_id'];

    // Update Profile Logic
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $city = trim($_POST['city']);
        $postal_code = trim($_POST['postal_code']);

        $stmt = $pdo->prepare("UPDATE users SET phone=?, address=?, city=?, postal_code=? WHERE id=?");
        $stmt->execute([$phone, $address, $city, $postal_code, $user_id]);
        $msg = "Profile Updated Successfully!";
    }

    // Fetch Current User Data
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | PC WIZARD</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        html { scroll-behavior: smooth; }
        .profile-container { max-width: 800px; margin: 4rem auto; padding: 3rem; border: 1px solid var(--border-color); border-radius: 8px; background: #fff; box-sizing: border-box; }
        .nav-logo { height: 95px !important; width: auto; max-height: none; margin: -10px 0; }
        .nav-item-dropdown { position: relative; display: inline-block; }
        .dropdown-content { display: none; position: absolute; background-color: #fff; min-width: 200px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); z-index: 100; border: 1px solid var(--border-color); border-radius: 4px; top: 100%; right: 0; }
        .dropdown-content a { color: var(--black); padding: 12px 16px; text-decoration: none; display: block; font-size: 0.9rem; border-bottom: 1px solid var(--border-color); }
        .dropdown-content a:hover { background-color: #f8f9fa; }
        .nav-item-dropdown:hover .dropdown-content { display: block; }
        
        /* Fixed Input Box Styling */
        .form-input { width: 100%; box-sizing: border-box; padding: 0.8rem; border: 1px solid var(--border-color); border-radius: 4px; outline: none; margin-top: 0.5rem; font-family: inherit;}
        .form-input:focus { border-color: var(--black); }
        .form-group { margin-bottom: 1.5rem; }
    </style>
</head>
<body>
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>
    
    <header class="header-wrapper">
        <nav class="navbar" style="border-bottom: 1px solid var(--border-color);">
            <a href="index.php" class="nav-brand">
                <img src="logo (2).png" alt="PC WIZARD Logo" class="nav-logo">
            </a>
            <div class="nav-center">
                <a href="index.php" class="nav-link"><i data-lucide="home"></i> HOME</a>
                <a href="shop.php" class="nav-link"><i data-lucide="shopping-bag"></i> SHOP</a>
            </div>
            <div class="nav-right">
                <div class="nav-item-dropdown">
                    <a href="#" class="auth-link" style="display:flex; align-items:center; gap:0.5rem; text-transform:uppercase;">
                        <i data-lucide="user" style="width:18px;"></i> HI, <?= htmlspecialchars($_SESSION['user_name']) ?>
                    </a>
                    <div class="dropdown-content">
                        <a href="user_profile.php" style="color: var(--black);">My Profile</a>
                        <a href="user_logout.php" style="color: #ef4444;">Logout</a>
                    </div>
                </div>
                <a href="cart.php" class="icon-btn">
                    <i data-lucide="shopping-cart"></i> <span class="cart-count badge" id="nav_cart_count">0</span>
                </a>
            </div>
        </nav>
    </header>

    <div class="profile-container">
        <h2 style="font-size: 1.5rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem; margin-bottom: 2rem;">MY PROFILE DETAILS</h2>
        
        <?php if($msg): ?>
            <div style="background: #d1fae5; color: #059669; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem; font-weight: 600;">
                <i data-lucide="check-circle" style="width: 18px; vertical-align: middle; margin-right: 5px;"></i> <?= $msg ?>
            </div>
        <?php endif; ?>

        <form action="user_profile.php" method="POST">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="color: var(--text-muted);">First Name (Unchangeable)</label>
                    <input type="text" class="form-input" value="<?= htmlspecialchars($user['first_name']) ?>" disabled style="background: #f8f9fa;">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="color: var(--text-muted);">Last Name (Unchangeable)</label>
                    <input type="text" class="form-input" value="<?= htmlspecialchars($user['last_name']) ?>" disabled style="background: #f8f9fa;">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" style="color: var(--text-muted);">Email Address (Unchangeable)</label>
                <input type="email" class="form-input" value="<?= htmlspecialchars($user['email']) ?>" disabled style="background: #f8f9fa;">
            </div>

            <h3 style="margin: 2.5rem 0 1.5rem 0; font-size: 1.2rem; color: var(--black); border-bottom: 1px dashed var(--border-color); padding-bottom: 0.5rem;">Update Contact Information</h3>

            <div class="form-group">
                <label class="form-label">Phone Number</label>
                <input type="text" name="phone" class="form-input" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="e.g. 01700000000">
            </div>

            <div class="form-group">
                <label class="form-label">Delivery Address</label>
                <input type="text" name="address" class="form-input" value="<?= htmlspecialchars($user['address'] ?? '') ?>" placeholder="House/Road/Area">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2.5rem;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label">City</label>
                    <input type="text" name="city" class="form-input" value="<?= htmlspecialchars($user['city'] ?? '') ?>" placeholder="e.g. Dhaka">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label">Postal Code</label>
                    <input type="text" name="postal_code" class="form-input" value="<?= htmlspecialchars($user['postal_code'] ?? '') ?>" placeholder="e.g. 1216">
                </div>
            </div>

            <button type="submit" name="update_profile" class="btn btn-solid" style="width: 100%; padding: 1rem 2rem; font-size: 1.1rem;">SAVE CHANGES</button>
        </form>
    </div>

    <script src="js/app.js"></script>
</body>
</html>