<?php
session_start();
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: user_login.php"); exit;
}
try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get User Data for Auto-fill
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
        $address = trim($_POST['shipping_address']);
        $city = trim($_POST['city']);
        $zip = trim($_POST['postal_code']);
        $payment_method = $_POST['payment_method']; 
        $total = $_POST['total_amount']; 
        $cart_data = json_decode($_POST['cart_data'], true); 

        if (!empty($cart_data)) {
            // 1. Insert into orders
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, shipping_method_id, shipping_address, city, postal_code, total_amount) VALUES (?, 1, ?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $address, $city, $zip, $total]);
            $order_id = $pdo->lastInsertId();

            // 2. Prepare statements for inserting items and reducing stock_quantity
            $item_stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)");
            $stock_update_stmt = $pdo->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");

            foreach ($cart_data as $item) {
                // Insert order item
                $item_stmt->execute([$order_id, $item['id'], $item['quantity'], $item['price']]);
                
                // Reduce stock from your exact database column
                $stock_update_stmt->execute([$item['quantity'], $item['id']]);
            }

            // 3. Insert into payments
            $pay_stmt = $pdo->prepare("INSERT INTO payments (order_id, payment_method, amount, payment_status) VALUES (?, ?, ?, 'Pending')");
            $pay_stmt->execute([$order_id, $payment_method, $total]);

            echo "<script>localStorage.removeItem('pc_wizard_cart'); alert('Order Placed via " . htmlspecialchars($payment_method) . "!'); window.location.href = 'index.php';</script>";
            exit;
        }
    }
} catch (PDOException $e) { die("Error: " . $e->getMessage()); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Secure Checkout</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        html { scroll-behavior: smooth; }
        .checkout-box { max-width: 800px; margin: 4rem auto; padding: 3rem; border: 1px solid var(--border-color); border-radius: 8px; background: #fff;}
        .payment-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem; }
        .payment-option { display: flex; align-items: center; gap: 0.75rem; padding: 1rem; border: 1px solid var(--border-color); border-radius: 4px; cursor: pointer;}
        .payment-option input[type="radio"] { accent-color: var(--black); transform: scale(1.2); }
        .nav-logo { height: 95px !important; width: auto; max-height: none; margin: -10px 0; }
        .nav-item-dropdown { position: relative; display: inline-block; }
        .dropdown-content { display: none; position: absolute; background-color: #fff; min-width: 150px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); z-index: 100; border: 1px solid var(--border-color); border-radius: 4px; top: 100%; right: 0; }
        .dropdown-content a { color: var(--black); padding: 12px 16px; text-decoration: none; display: block; border-bottom: 1px solid var(--border-color); }
        .dropdown-content a:hover { background-color: #f8f9fa; }
        .nav-item-dropdown:hover .dropdown-content { display: block; }
    </style>
</head>
<body>
    <div class="cursor-dot"></div><div class="cursor-outline"></div>

    <header style="padding: 1rem 3rem; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
        <a href="index.php"><img src="logo (2).png" alt="Logo" class="nav-logo"></a>
        <div class="nav-right" style="display: flex; align-items: center; gap: 2rem;">
            <div style="font-weight: 600; display: flex; align-items: center; gap: 0.5rem; color: #10b981;">
                <i data-lucide="lock" style="width: 18px;"></i> SECURE CHECKOUT
            </div>
            <div class="nav-item-dropdown">
                <a href="user_profile.php" class="auth-link" style="display:flex; align-items:center; gap:0.5rem;">
                    <i data-lucide="user" style="width:18px;"></i> HI, <?= htmlspecialchars($_SESSION['user_name']) ?>
                </a>
                <div class="dropdown-content">
                    <a href="user_profile.php">My Profile</a>
                    <a href="user_logout.php" style="color: #ef4444;">Logout</a>
                </div>
            </div>
        </div>
    </header>

    <div class="checkout-box">
        <h2 style="font-size: 1.5rem; margin-bottom: 2rem; border-bottom: 1px solid var(--border-color); padding-bottom: 1rem;">SHIPPING DETAILS</h2>
        <form action="checkout.php" method="POST">
            <input type="hidden" name="cart_data" id="hidden_cart_data">
            <input type="hidden" name="total_amount" id="hidden_total">

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
                <div>
                    <label class="form-label">Contact Name</label>
                    <input type="text" class="form-input" value="<?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>" disabled style="background: #f8f9fa;">
                </div>
                <div>
                    <label class="form-label">Phone Number *</label>
                    <input type="text" name="phone" class="form-input" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required>
                </div>
            </div>

            <div class="form-group" style="margin: 1.5rem 0;">
                <label class="form-label">Delivery Address * <span style="font-size: 0.8rem; color: var(--text-muted); font-weight: normal;">(You can change this for a different delivery location)</span></label>
                <input type="text" name="shipping_address" class="form-input" value="<?= htmlspecialchars($user['address'] ?? '') ?>" placeholder="House/Road/Area" required>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 2.5rem;">
                <div><label class="form-label">City *</label><input type="text" name="city" class="form-input" value="<?= htmlspecialchars($user['city'] ?? '') ?>" required></div>
                <div><label class="form-label">Postal Code *</label><input type="text" name="postal_code" class="form-input" value="<?= htmlspecialchars($user['postal_code'] ?? '') ?>" required></div>
            </div>

            <label class="form-label" style="font-size: 1.1rem; color: var(--black);">Select Payment Method *</label>
            <div class="payment-grid" style="margin-bottom: 2.5rem;">
                <label class="payment-option"><input type="radio" name="payment_method" value="Cash on Delivery" checked> <span style="font-weight: 600;"><i data-lucide="truck" style="color: var(--text-muted); width: 18px; margin-right: 5px;"></i> Cash on Delivery</span></label>
                <label class="payment-option"><input type="radio" name="payment_method" value="bKash"> <span style="font-weight: 600;"><i data-lucide="smartphone" style="color: #e2136e; width: 18px; margin-right: 5px;"></i> bKash</span></label>
                <label class="payment-option"><input type="radio" name="payment_method" value="Nagad"> <span style="font-weight: 600;"><i data-lucide="smartphone" style="color: #ed1c24; width: 18px; margin-right: 5px;"></i> Nagad</span></label>
                <label class="payment-option"><input type="radio" name="payment_method" value="Card Payment"> <span style="font-weight: 600;"><i data-lucide="credit-card" style="color: var(--text-muted); width: 18px; margin-right: 5px;"></i> Card</span></label>
            </div>

            <button type="submit" name="place_order" class="btn btn-solid" style="width: 100%; padding: 1rem; font-size: 1.1rem;">CONFIRM ORDER</button>
        </form>
    </div>
    
    <script>
        let cart = JSON.parse(localStorage.getItem('pc_wizard_cart')) || [];
        let total = 0; cart.forEach(i => total += i.price * i.quantity); total += 150;
        document.getElementById('hidden_total').value = total;
        document.getElementById('hidden_cart_data').value = JSON.stringify(cart);
    </script>
    <script src="js/app.js"></script>
</body>
</html>