<?php
session_start();
try {
    $pdo = new PDO("mysql:host=localhost;dbname=pc_wizard_db;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    $stmt = $pdo->prepare("
        SELECT p.*, b.name AS brand, c.name AS category 
        FROM products p 
        LEFT JOIN brands b ON p.brand_id = b.id 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE p.id = ?
    ");
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        die("<h2>Product not found in Database!</h2>");
    }

    $stock = (int)($product['stock_quantity'] ?? 0); 
    if ($stock > 0) {
        $stock_status = "<span style='color: #10b981; font-weight: 600;'>In Stock ({$stock} Pieces)</span>";
    } else {
        $stock_status = "<span style='color: #ef4444; font-weight: 600;'>Out of Stock</span>";
    }

    $nav_stmt = $pdo->query("SELECT id, name FROM categories LIMIT 6");
    $nav_categories = $nav_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['title']) ?> | PC WIZARD</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        html { scroll-behavior: smooth; }
        .nav-logo { height: 95px !important; width: auto; max-height: none; margin: -10px 0; }
        .nav-item-dropdown { position: relative; display: inline-block; }
        .dropdown-content { display: none; position: absolute; background-color: #fff; min-width: 150px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); z-index: 100; border: 1px solid var(--border-color); border-radius: 4px; top: 100%; right: 0; }
        .dropdown-content a { color: var(--black); padding: 12px 16px; text-decoration: none; display: block; font-size: 0.9rem; border-bottom: 1px solid var(--border-color); }
        .dropdown-content a:hover { background-color: #f8f9fa; }
        .nav-item-dropdown:hover .dropdown-content { display: block; }
        .search-box { display: flex; align-items: center; border: 1px solid var(--border-color); border-radius: 20px; padding: 2px 10px; background: #fff; }
        .search-box input { border: none; outline: none; padding: 5px 10px; font-size: 0.9rem; width: 180px; background: transparent; }
    </style>
</head>
<body>
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>

    <header class="header-wrapper">
        <nav class="navbar" style="border-bottom: 1px solid var(--border-color);">
            <a href="index.php" class="nav-brand"><img src="logo (2).png" alt="PC WIZARD Logo" class="nav-logo"></a>
            
            <div class="nav-center">
                <a href="index.php" class="nav-link"><i data-lucide="home"></i> HOME</a>
                <div class="nav-item-dropdown">
                    <a href="shop.php" class="nav-link"><i data-lucide="shopping-bag"></i> SHOP <i data-lucide="chevron-down"></i></a>
                    <div class="dropdown-content">
                        <?php foreach($nav_categories as $cat): ?>
                            <a href="shop.php?category=<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <a href="#contact-footer" class="nav-link"><i data-lucide="phone-call"></i> CONTACT US</a>
            </div>

            <div class="nav-right">
                <?php if(isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true): ?>
                    <div class="nav-item-dropdown">
                        <a href="user_profile.php" class="auth-link" style="display:flex; align-items:center; gap:0.5rem; text-transform:uppercase;">
                            <i data-lucide="user" style="width:18px;"></i> HI, <?= htmlspecialchars($_SESSION['user_name']) ?>
                        </a>
                        <div class="dropdown-content">
                            <a href="user_profile.php" style="color: var(--black);">My Profile</a>
                            <a href="user_logout.php" style="color: #ef4444;">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="user_login.php" class="auth-link">LOGIN / REGISTER</a>
                <?php endif; ?>

                <form action="shop.php" method="GET" class="search-box">
                    <input type="text" name="search" placeholder="Search products...">
                    <button type="submit" style="background:none; border:none; cursor:pointer;"><i data-lucide="search" style="width: 18px;"></i></button>
                </form>
                <a href="cart.php" class="icon-btn"><i data-lucide="shopping-cart"></i> <span class="cart-count badge" id="nav_cart_count">0</span></a>
            </div>
        </nav>
    </header>

    <div class="page-container">
        <div class="product-detail-layout" style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem;">
            
            <div class="detail-gallery" style="aspect-ratio: 4/5; overflow: hidden; background: var(--surface-color); position: sticky; top: 120px;">
                <img src="<?= htmlspecialchars($product['image_url']) ?>" alt="<?= htmlspecialchars($product['title']) ?>" style="width: 100%; height: 100%; object-fit: contain; padding: 2rem;">
            </div>

            <div class="detail-info" style="display: flex; flex-direction: column; gap: 1.5rem;">
                <div>
                    <div class="product-brand" style="font-size: 1rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.5rem;">
                        <?= htmlspecialchars($product['brand'] ?? 'PC WIZARD') ?> | <?= htmlspecialchars($product['category'] ?? 'Component') ?>
                    </div>
                    <h1 style="font-size: 3rem; margin-bottom: 1rem; line-height: 1.1;">
                        <?= htmlspecialchars($product['title']) ?>
                    </h1>
                    <div class="detail-price" style="font-size: 2.5rem; font-weight: 600; color: var(--black);">
                        ৳<?= number_format($product['price'], 2) ?>
                    </div>
                </div>

                <p class="detail-description" style="color: var(--text-muted); font-size: 1.1rem; line-height: 1.8;">
                    High-performance <?= htmlspecialchars($product['category'] ?? 'component') ?> engineered for absolute precision. Upgrade your setup with the <?= htmlspecialchars($product['brand'] ?? '') ?> <?= htmlspecialchars($product['title']) ?>. Pure performance, zero distractions.
                </p>

                <!-- 100% Corrected Add to Cart Button -->
                <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                    <?php if ($stock > 0): ?>
                        <button class="btn btn-solid" style="padding: 1rem 2rem; font-size: 1.1rem; flex: 1;" onclick="addToCart(
                            <?= $product['id'] ?>, 
                            '<?= htmlspecialchars(addslashes($product['title'])) ?>', 
                            <?= $product['price'] ?>, 
                            '<?= htmlspecialchars(addslashes($product['image_url'])) ?>',
                            '<?= htmlspecialchars(addslashes($product['brand'] ?? 'PC WIZARD')) ?>'
                        )">ADD TO CART</button>
                    <?php else: ?>
                        <button class="btn" style="padding: 1rem 2rem; font-size: 1.1rem; flex: 1; background: #d1d5db; color: #4b5563; cursor: not-allowed;" disabled>
                            OUT OF STOCK
                        </button>
                    <?php endif; ?>
                    
                    <button class="btn btn-outline" style="width: auto; padding: 1rem;"><i data-lucide="heart"></i></button>
                </div>

                <div class="detail-specs" style="border-top: 1px solid var(--border-color); padding-top: 2rem; margin-top: 2rem;">
                    <div class="spec-row" style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-color); padding: 1rem 0;">
                        <span style="font-weight: 600;">Category</span>
                        <span style="color: var(--text-muted); text-transform: uppercase;"><?= htmlspecialchars($product['category'] ?? 'General') ?></span>
                    </div>
                    <div class="spec-row" style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-color); padding: 1rem 0;">
                        <span style="font-weight: 600;">Availability</span>
                        <span><?= $stock_status ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification Container -->
    <div id="toast_container" style="position: fixed; bottom: 20px; right: 20px; z-index: 1000; display: flex; flex-direction: column; gap: 10px;"></div>

    <footer class="footer" id="contact-footer" style="margin-top: 4rem;">
        <div class="footer-grid">
            <div class="footer-brand">
                <img src="logo (2).png" alt="PC WIZARD Logo" style="height: 60px; margin-bottom: 1.5rem;">
                <p>PC WIZARD is made by ENTHUSIASTS, ensuring top-tier performance.</p>
            </div>
            <div class="footer-col">
                <h4>IMPORTANT LINKS</h4>
                <ul><li><a href="admin/login.php" style="color: var(--black); font-weight: 600;">Admin Panel</a></li></ul>
            </div>
        </div>
    </footer>

    <script src="js/app.js"></script>
</body>
</html>